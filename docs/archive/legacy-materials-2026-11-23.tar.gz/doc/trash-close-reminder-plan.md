# 关闭窗口时的废纸篓提醒

本文记录 0.4.3 的初始方案；现行直接清空和退出等待规则见 [退出复用计划](trash-exit-reuse-plan.md)，不再使用 Open Trash 分支。

## 目标与方案

本次累计清理容量大于 0 时，在用户关闭主窗口或直接退出应用前显示原生提醒，引导用户检查并清空系统废纸篓以释放空间，提供跨重启生效的“不再提醒”。使用现有会话统计，不检测或删除废纸篓内容，不把累计清理量当作实际释放空间。

采用 NSWindow.willCloseNotification 观察主窗口，保留 SwiftUI 自身的窗口 delegate 与 Dock 重开行为；应用直接退出复用同一提醒状态，保留原有更新退出门禁。原生 NSAlert 提供“打开废纸篓”和继续关闭/退出两条路径。相同累计容量确认后不重复提醒，有新增清理后重新提醒；永久关闭提醒保存在 UserDefaults。

仅在退出回调提醒会漏掉红色关闭按钮；替换 SwiftUI 窗口 delegate 会干扰窗口生命周期，均不采用。打开废纸篓失败时显示明确错误。按用户后续反馈，弹窗正文压缩为“本次已清理 {0}，清空废纸篓以释放空间。”容量保持“已清理”口径，不承诺清空废纸篓能释放全部累计容量。

## 实施计划

- [x] 在 Tests/CleanerCoreTests 添加容量边界、重复关闭、新增清理和偏好持久化测试，先运行观察缺失功能的失败。
- [x] 添加 CleanerCore/TrashReminderState.swift，集中管理提醒条件、已确认容量与永久关闭偏好。
- [x] 添加 CleanerApp/TrashReminderController.swift，使用原生提醒；CleanerApp.swift 接入主窗口关闭和退出，共用一个状态实例。
- [x] 添加中英文资源；更新 README.md、doc/architecture.md、doc/development.md 及原有 docs 中对应入口。
- [x] 运行定向测试、swift test、CoreContractChecks、语言检查和 App 构建；测试与验证记录集中在根目录 Tests/trash-close-reminder。
- [x] 用 git diff 逐文件检查本次增量，记录必要性、验证结果和局部/全局建议评分，不提交或推送。

## 约束与复核重点

- Swift 6 / macOS 13，复用 AppKit、Foundation 和现有 SwiftPM 依赖，不新增 Python 包或 requirements.txt。
- 不重置本次累计统计，不修改扫描、删除、恢复和系统权限策略。
- 0 字节不提醒；永久关闭后跨进程不提醒；一个会话同一容量不连续提醒；新增清理可再次提醒。
- 最小化、关闭其他面板和取消更新退出不触发提醒；仅主窗口注册关闭通知。
- 根目录 AGENTS.md 和 .trae/rules/project_rules.md 均不存在，不创建额外规则文件。保留原有未提交改动。

## 执行记录

使用 writing-plans 的先计划后实施流程；按用户一次完成、减少询问的要求，在当前工作区连续执行。所有验证材料使用现有 Tests 目录（本机大小写不敏感，与 tests 为同一目录）。

局部建议：原生关闭提醒与持久关闭选项，100 分，纳入本次实施。全局建议：窗口关闭和退出复用同一状态，避免重复提醒和漏提醒，95 分，纳入本次实施。其余不扩展功能。

完成：0.4.3（117）已签名打包并更新固定安装路径，完整测试 264 项通过；用户反馈后的精简文案、原生交互和跨进程偏好验证通过。独立复核指出 UI 夹具的阴性断言不足，已改为实际弹窗计数并重新完成验证；系统中断 modal 不写入确认状态。逐文件必要性与全部证据见 [验收记录](../Tests/trash-close-reminder/README.md)。
