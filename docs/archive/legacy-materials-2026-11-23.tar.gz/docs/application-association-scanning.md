# 应用关联扫描

本批次增加基础分析后的运行观察。基础结果先展示，运行中的非系统应用随后执行 3 次打开文件采样；刷新应用也走相同流程。展开应用后可执行 5 次的深度关联扫描，并在过程中停止。

未运行的应用必须在界面确认后才会启动。启动使用“不激活、隐藏”配置，但应用仍会真实执行，可能显示窗口、联网和修改数据。只对能确认由本次操作新启动的进程请求正常退出，不强制结束进程，也不退出原先已运行的应用。结束或取消后重新分析运行状态。观察期间禁止卸载和更新。

## 两种证据

- **应用包声明**：有界读取 Electron 的 `Resources/app/package.json` 或 `Resources/app.asar`，检查声明的主入口。识别 `app.setPath('userData', path.join(app.getPath('appData'), '目录名'))`，包括构建器生成的 `(0,path.join)` 以及环境变量回退表达式。不执行 JavaScript，不读取凭据内容。支持的表达式必须只有一个明确目录；注释、字符串示例、正则字面量、动态插值、路径穿越、符号链接及损坏归档不会授权删除。该能力不是完整 JavaScript 语义分析；未识别的动态路径由运行观察补充线索。
- **运行观察**：通过 `ps` 归属应用进程和后代进程，通过 `lsof` 获取当前打开的文件。只展示用户 Library 中数据、缓存、日志及容器根目录下的关联目录，不记录文件内容，不将用户文稿或系统依赖列入卸载范围。采样间隔最多 2 秒、最多 5 次，单次命令和输出均有限制。未采到的短暂访问不代表不存在，权限受限和取消明确显示。它不是 Endpoint Security 全量事件追踪。

应用包声明的用户数据经现有共享、副本、引用和保护策略校验后，可手动选择。运行访问本身不改变删除资格。删除前重新读取声明并检查应用内进程；计划先处理关联数据，再处理应用本体，保证归属证据尚可重新读取。声明扫描达到时间预算时不采用不完整的声明集合授权删除。

## 验证

- `swift run CoreContractChecks --check-application-discovery`：声明、ASAR 边界、共享副本、符号链接、失效声明、删除顺序、进程归属、真实打开文件采样、采样去重、取消和退出实例策略。
- `swift run CoreContractChecks --check-installed-uninstall '/Applications/Cetus ADE.app'`：真实应用只读分析，本批次验证从 2 项增加到 3 项，不执行卸载。
- `swift run CoreContractChecks`：项目完整独立契约检查。
- `python3 Scripts/check-localizations.py`：中英文覆盖。

本批次尝试运行 XCTest，但原有 `SystemScanCoordinatorTests`、`AgentScannerTests`、`HelperProtocolTests`、`HistoryStoreTests`、`ExecutionTests` 有编译错误。因此本次新增回归覆盖放在项目现有 CoreContractChecks 中，打包时使用 `SUPERCLEANER_SKIP_XCTEST=1`，并保留完整契约检查和包内自检。

## 诊断文件专项扫描（0.0.9）

- 扫描用户 `Library/Application Support/CrashReporter` 的日期记录、`Library/Logs/DiagnosticReports` 与 `Library/Logs/CrashReporter` 中的 `.ips` / `.crash` 文件，以及报告目录下一层 `Retired`。系统 `/Library/Logs` 下对应报告可以展示，但保持保护。
- `.ips` 支持单 JSON 和“元数据行＋正文 JSON”，只使用顶层应用标识、进程路径和名称；`.crash` 只解析开头的报告头，不根据调用栈或加载库猜归属。标识冲突、仅名称线索或报告损坏时不能删除。
- 日期记录必须符合 `<可执行名称>_<UUID>.plist`，内容仅包含有效 `Date` 和/或 `ForceQuitDate`，并与应用 Info.plist 中的 Bundle ID / CFBundleExecutable 核对。不会把 `ImageViewerPro` 当作 `ImageViewer`。0.0.10 补充强制退出记录；未知字段、空记录或无效日期仍保持保护。
- 公共诊断目录本身被排除，即便某应用显示名或包内数据声明恰好同名。只生成单文件关联，默认不选；归属图继续核对副本、共享和引用，执行前再次解析当前报告。
- 每个报告最多读取 2 MiB，合计 32 MiB，最多 5,000 项、5 秒；取消、超限、权限和格式错误会保留覆盖受限信息。不保存报告正文或堆栈。
- `swift run CoreContractChecks --check-application-diagnostics` 覆盖上述格式、旧版报告、Retired、前缀碰撞、冲突、损坏、副本、共享根目录、符号链接、系统目录、权限、预算、取消和执行前重新验证。
- 本机 ImageViewer 只读复测从 3 项增加到 6 项：新增 240 字节日期记录和两份 `.ips` 报告。验证不删除真实应用或报告。

## 卸载执行与列表同步（0.0.11）

- 修复现场采样确认的卡顿：压缩 JavaScript 中的长标识符会让原来的全文件正则反复尝试后缀。现在先定位 `.setPath(`，再做锚定匹配；接收者最多 512 字符、表达式窗口最多 4,096 字符、最多 1,024 个候选调用，超限或取消时不采用声明。
- 逐项执行仍重新读取当前应用清单、副本、引用、安装来源及声明，但只构建当前资源的归属结果。服务定义继续完整核对；普通缓存、偏好设置等不再触发无关的用户数据声明解析。不会用缓存的旧归属结果授权删除。
- 卸载使用真实逐项进度。校验期间收到停止请求时，不再移动待处理项目。删除结果返回后直接按成功文件效果同步列表，不再把全应用重扫和运行采样计入“正在删除”的等待。
- 同步大文件树、文件数量、父目录大小、候选项、勾选状态和应用清单；目录删除会同时移除其下的扫描条目，边界相似的兄弟路径不受影响。失败、跳过和结果待确认的项目继续保留，扫描时间和覆盖限制保持原样。
- `--check-cleanup-refresh` 覆盖索引/层级大文件、部分成功、目录子项、统计更新、重复回执及应用本体/仅数据删除。`--check-application-discovery` 增加长压缩代码和临时应用完整卸载；`--check-planning-execution` 增加校验期间停止后无文件移动的检查。

## 逐项反馈与执行开销（0.1.1）

- 普通系统清理不再为每个文件启动一次 `ps`；运行中应用标识仍按当前状态读取，项目和 Agent 的进程校验继续保留。应用复核只检查当前资源所有者的安装来源，并先做字面包含判断，再运行配置引用边界匹配。
- 规则存储仍在每次执行校验时读取、验签并合并撤销信息；只有完全相同的已验证规则包的摘要可以复用，激活、回滚、撤销、规则内容变化和损坏都会立即使摘要失效或拒绝执行。
- 每个结果完成校验后即通过进度回调发布，界面按 150 毫秒合并更新，批次结束时立即补齐；操作标识阻止迟到回调影响新批次。成功项及时移除，失败项保留并显示原因。
- 对明确不存在的原文件返回 `sourceMissing + skipped`，同步移除旧列表条目，但不计入清理数量、释放空间或恢复内容。读取失败和身份变化不等同于文件不存在，继续保留。
- 回归检查增加逐项结果先于下一项发布、边执行边停止、文件缺失快速返回、缺失项不计清理成果、逐项更新后最终回执跟踪，以及摘要缓存仍拒绝损坏或变化规则。
- 同机 release 构建的 170 个临时日志完整执行对比为 8.03 秒 → 1.31 秒（包含实时规则/保护校验、移动及移动后身份验证）。性能探针仅操作临时目录，不删除真实日志；实际耗时仍取决于目录内容和权限。


## 统一关联目录与 XApp 覆盖移植（0.1.4）

- 通过 REA 静态核对 XApp 当前二进制的 11 类入口、24 个固定目录，详细证据、完整路径矩阵和保留未知见 [xapp-uninstall-coverage.md](xapp-uninstall-coverage.md)。目录发现、执行前归属复核和运行观察共用 `ApplicationAssociationPathRegistry`，不再维护三份不同的基础目录清单。
- 补齐 `Application Scripts`，即使专属目录为空也保留为可手选项；新增 ByHost 的严格 UUID 偏好、专属 Cookie、当前用户真实 Darwin cache/temp 子项。插件、系统收据、服务与全局目录仅关联展示，不用新增目录绕过原有卸载能力边界。
- 厂商目录最多多看一层，匹配具体产品，永不认领厂商父目录；应用包内有界发现的子 Bundle ID 可参与容器、偏好等归属核对。未知兼容偏好 ID 只给线索，Chrome 主浏览器不认领独立 Web app 的缓存。
- 每项仍核对其他已安装应用、副本、组声明和配置/服务引用，执行前重新扫描当前资源。公共扫描根、目录链接、相似前缀、预算耗尽前未发现的资源不会因移植获得删除资格。
- 运行观察已经出现在卸载清单的路径标为“已列入上方卸载清单，可勾选删除”；受保护项显示保护提示。只读注册组件标为“仅关联展示”，避免混同“归属待确认”。
- 新增 `CoreContractChecks --check-association-roots`：隔离临时目录中验证三项发现、空脚本目录、严格名称、共享副本、子 Bundle ID、Chrome 特例、兼容线索保护、定向复核、预算/取消、链接拒绝，以及真实隔离/恢复往返。真实 RawTherapee 仅做只读计划和执行前归属校验，不移动或删除实际应用和数据。


本批次最终验证：完整 debug / release CoreContractChecks 通过，921 条中英文消息校验通过；临时三项应用卸载和恢复往返通过。本机 RawTherapee 使用完整已安装所有者清单只读复测，实际得到 4 个可选项（应用本体、空 Application Scripts、Containers、Darwin 用户缓存），三个关联项的执行前校验全部通过，未删除真实应用或数据。App、Helper、中英文设置页和挂载 DMG 均为 `0.1.4 (19)`；DMG 内三个可执行文件散列与构建产物一致，签名及启动/界面自检通过。XCTest 因前述仓库已有编译问题跳过，完整 CoreContractChecks 已运行。验证日志和散列记录保存在 REA 报告目录的 `migration-validation.json` 及对应日志中。


## 持续写入日志的身份校验（0.1.5）

- 现场只读检查确认 Codex 日志在同一设备号/inode 下持续增加大小。旧执行器把大小和修改时间一起作为不可变化的身份快照，导致普通日志反复返回 `skippedIdentityChanged`。
- 仅对 `source=general`、`category=log`、`ruleID=general.logs` 且原身份为普通文件的项目，允许内容/修改时间改变；设备号、inode、类型仍必须一致。其他缓存、大文件、应用卸载数据和链接保持完整快照校验。准备隔离目录后、实际移动前再检查一次，拒绝这段时间内发生的日志轮转或替换。
- 移动后和重启时继续验证所选文件对象；写入进程在原路径生成不同的普通日志时，保留新文件并确认旧对象已移入恢复区。记录移动时观察到的实际日志大小。仍打开的普通文件恢复时验证原对象身份，避免追加写入造成虚假的恢复失败；原路径存在新文件时继续恢复到相邻路径，不覆盖。
- `CoreContractChecks --check-changing-logs` 使用隔离临时文件和真实打开的写入句柄，覆盖扫描后追加、移动中/隔离后写入、新日志生成、重启核对、恢复冲突、准备期间替换、轮转、符号链接替换与普通大文件的严格校验。将身份策略切回完整快照时，测试确定性复现截图同样的 `File identity changed`；修复后通过。没有读取或删除真实 Codex 日志内容。

本批次最终验证：新增日志场景（含最后一次身份读取期间的停止/过期）及完整 release CoreContractChecks 通过，App 与挂载 DMG 的版本、Helper 和中英文设置均为 `0.1.5 (20)`，可执行文件散列及签名核对通过；DMG 已更新。验证记录保存在当前聊天的 `log-identity-fix-20261029/validation.json`。XCTest 沿用前述已有编译问题的跳过方式，未把它计作通过。


## 深度观察的保留价值与排版（0.1.6）

- 保留手动深度关联观察：固定目录、包标识和声明扫描仍无法独立确认所有运行时配置的自定义目录。观察结果能补充此类路径线索，但不会仅凭访问记录添加可删除项；对基础扫描已确认的路径主要是重复核对。未运行应用仍须确认后才启动，观察后重新分析归属，行为边界不变。
- 深度观察区域填满可用宽度并靠左，以与卸载子项相同的 66 点起始位置排版；采样中的进度指示放在“停止观察”按钮之后，避免按钮在工作时向右跳动。
- 扩充现有运行观察契约：真实打开一个临时、未被静态卸载计划认领的 `RuntimeChosenStore/state.db`，确认运行采样可发现目录，同时它不因此进入可删除清单。测试不启动、退出或卸载用户的真实应用。

本批次完整 release CoreContractChecks、App 自检及挂载 DMG 的版本/签名/散列核对均通过；App、Helper、中英文设置一致为 `0.1.6 (21)`，DMG 已更新。


## 系统缓存扫描后的变化（2026-11-11）

- 通用用户缓存规则允许同一设备、inode 和类型的内容变化；目录移动前再次完整检查，文件替换、符号链接和新增敏感内容仍拒绝执行。普通大文件和应用数据继续使用严格快照。
- 执行阶段与 GUI 完整扫描一致，不使用条目数量上限；仍保留目录深度、权限、保护规则和取消检查，避免已扫描的 2 万项以上缓存目录因执行阶段预算不同而被拒绝。
- 执行规则检查读取当前文件身份；安全策略拒绝项在首页显示“已跳过”，不再统一提示重新扫描。删除仍使用现有隔离与恢复流程，缓存目录字节数沿用扫描估算。
- `--check-changing-logs` 增加真实临时缓存文件、目录、20,001 个子项、新增敏感文件、替换目录及恢复场景，使用生产运行时的批量与逐项校验；不删除用户真实缓存。

### 运行状态切换与清单复用

首次扫描也为运行中的非系统应用准备卸载清单及关联索引，但不提供可执行卸载项目。系统应用仅在 Protected 与 All 中显示；其余应用运行中只进入 Running，未运行只进入 Uninstallable，三个分类互斥。在 Running 勾选请求退出，退出后立即移入 Uninstallable 并复用原清单、大小统计和项目 ID，不重新遍历文件。重新启动会移回 Running，撤回可执行清单并清除卸载选择。缺失清单的应用先显示在对应范围中，再使用缓存关联索引补齐该应用；首次分析失败且仍无清单时，退出后允许补齐一次。清理结果同步移除缓存清单中的已删除项目，防止状态切换恢复旧项目。真正执行删除时仍检查当前运行状态、路径和归属。

旧报告如果连关联索引也缺失，会明确提示刷新应用列表，不会因为退出动作偷偷重扫所有应用。

“可卸载”筛选下统一展示卸载清单和归属说明，不展示运行观察区域（深度关联扫描入口、采样提示、观察路径及“在访达中查看”按钮）。观察记录仍保留，在其他筛选视图中按原逻辑展示；切换列表不会把观察路径转成可删除项目。

### Dock icons after uninstall and restore

The GUI captures only Dock tiles whose exact application path is selected for uninstall. After confirmed removal of the application bundle, it removes those tiles from `persistent-apps` and `recent-apps` and refreshes the current user's Dock once per batch. Failed, unverified and associated-files-only operations do not remove icons; other installed copies are matched by path, not name or bundle ID.

Affected tiles and positions are saved under `Library/Application Support/SuperCleaner/DockRecovery` before editing Dock preferences. Recovery merges the saved tiles into the current layout, skips already present tiles and redirects conflict restores to their actual destination without reusing stale bookmarks. Interrupted changes retry from persisted receipts on launch. Dock failures appear separately in deletion results and recovery history; they do not change a successful file operation into a failure. The Dock briefly restarts when an actual preference change needs to be displayed. Existing icons from uninstalls before this feature have no saved receipt-to-tile mapping and are not removed retroactively.
